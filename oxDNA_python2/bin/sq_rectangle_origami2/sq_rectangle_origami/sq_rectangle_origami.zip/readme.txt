-- CanDo submission --

Date and time: 2021-06-22 01:40:04
Name: ochatake
University/Institute/Company: Ochanomizu University
Email: takedrago@gmail.com
Filename: sq_rectangle_origami.json
File type: square
Axial rise: 0.34
Helix diameter: 2.25
Crossover Spacing: 10.5
Axial stiffness: 1100
Bending stiffness: 230
Torsional stiffness: 460
Nick stiffness factor: 0.01
Model: coarse
Movie: yes
Logged in: TRUE
#ifndef NUPACK_THERMO_CONCENTRATIONS_H__
#define NUPACK_THERMO_CONCENTRATIONS_H__

#include "concentrations/CalcConc.h"
#include "concentrations/FracPair.h"

#endif /* NUPACK_THERMO_CONCENTRATIONS_H__ */
